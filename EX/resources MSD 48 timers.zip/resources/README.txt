response-template.tex: template for your response, latex
response-template.docx: template for your reponse, word
src: source of X24 programs
src/test: Java programs that test the generated code from X24 programs
src-gen: generated Java code for the X24 programs