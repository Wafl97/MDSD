/**
 * 
 */
/**
 * 
 */
module ExamRuntime {
	requires org.junit.jupiter.api;
}